## 140.886: Intro to R
## Homework 2

# Questions
# 1)	Read in the dataset itself, naming the R object "cars" into R. Use read_csv
# Read in the dictionary and name it key.  Use read_tsv
cars <- read_csv("http://johnmuschelli.com/intro_to_r/data/kaggleCarAuction.csv")
key <- read_tsv("http://johnmuschelli.com/intro_to_r/data/Carvana_Data_Dictionary_formatted.txt")

### Save the key and data in an ".rda" file so you can access the data offline. 
# use the save(cars, key, file = "kaggle.rda")
save(cars, key, file = "kaggle.rda")

# 2)	How many cars are in the dataset? How many variables are recorded for each car?
# nrow counts what?  ncol counts what?  what does dim do?  
# what does length(cars) give you?

nrow (cars)
##### nrow counts the numbers of cars in the dataset
ncol (cars)
##### ncol counts the number of variables in the data set
dim(cars)
##### dim gives the dimensions of the dataset (both the number of cars and variables)
length(cars)
##### length(cars) gives the number of columns/elements (variables) in the data set

# 3)	What is the range of the manufacturer's years of the vehicles? Use VehYear
# use the $ notation to extract VehYear
range(cars$VehYear)
##### Range is 2001 to 2010
# How many cars were from before 2004,
sum(cars$VehYear < 2004)
##### 11,113 cars
# and percent/proportion of these in the population?
sum(cars$VehYear < 2004)/sum(cars$VehYear)
#####Nearly 0% of cars are from before 2004
# use summarize/filter or sum

# 4)	Drop any vehicles that cost less than or equal to $1500 (VehBCost), 
# or missing - (filter removes missing values !)
sum(cars$VehBCost <= 1500 | is.na(cars$VehBCost))
cars = filter(cars, VehBCost > 1500)
nrow(cars)
# how many vehicles were removed? 
##### 71 cars removed
# The rest of the questions expect answers based on this reduced dataset.

# 5)	How many different vehicle a) manufacturers/makes (Make)
length(unique(cars$Make))
table(unique(cars$Make))
##### 33 different kinds of car manufacturers
# b) models (Model)
length(unique(cars$Model))
##### 1057 different kinds of car models 
# and c) sizes (Size) are there?
length(unique(cars$Size))
table(unique(cars$Size))
##### 13 sizes of cars
# use table or group_by with tally/summarizeleng

# 6)	Which vehicle a) make, b) model and c) color had the highest average 
# acquisition cost paid for the vehicle at time of purchase, and what was 
# this cost?
# use  group_by with summarize
#a) make
cars %>% group_by(Make) %>% summarize(mean=mean(VehBCost)) %>% arrange(desc(mean))
##### Lexus, Hummer, Cadillac, Volvo, Infiniti
#b) model
cars %>% group_by(Model) %>% summarize(mean=mean(VehBCost)) %>% arrange(desc(mean))
##### Escalade, GX470, RX400H, GS450, Touareg
#C)color
cars %>% group_by(Color) %>% summarize(mean=mean(VehBCost)) %>% arrange(desc(mean))
##### Black, Grey, Brown, Other, Beige

# 7)	Which vehicle a) make, b) model and c) color had the highest variability 
# in acquisition cost paid for the vehicle at time of purchase?
#a) make
cars %>% group_by(Make) %>% summarize(var=var(VehBCost)) %>% arrange(desc(var))
##### Lexus, Cadillac, Infiniti, Lincoln, Volkswagen
#b) model
cars %>% group_by(Model) %>% summarize(var=var(VehBCost)) %>% arrange(desc(var))
##### Highlander, RX400H, 2500 Silverado Pickup, 4 Runner, F150 Pickup
#c) color
cars %>% group_by(Color) %>% summarize(var=var(VehBCost)) %>% arrange(desc(var))
##### Maroon, black, grey, red, other

# 8)	Display the relationship between acquisition cost and mileage, 
# and describe this relationship
# maybe see if you can do a plot, see the cor function
plot(VehBCost ~ VehOdo, ylab = "Acquisition cost", xlab = "Mileage", main = "Relationship Between Acquisition Cost and Mileage", data = cars)
plot(log2(VehBCost) ~ VehOdo, ylab = "Acquisition cost", xlab = "Mileage", main = "Relationship Between Acquisition Cost and Mileage", data = cars)

# 9)	Which variables of cost, odometer reading, and/or 
# warranty (if any) visually appear to associate with a car 
# being a "lemon"/bad purchase?  Do a scatterplot matrix or 
# series of scatterplots
#cost
boxplot(VehBCost ~ cars$IsBadBuy, ylab="Cost", xlab = "Bad Buy?", main = "Relationship Between Acquisition Cost and Being a Bad Buy", data=cars)
#odometer reading
boxplot(VehOdo ~ cars$IsBadBuy, ylab="Odometer Reading", xlab = "Bad Buy?", main = "Relationship Between Odometer Reading and Being a Bad Buy", data=cars)
#warranty
boxplot(WarrantyCost ~ cars$IsBadBuy, ylab="Warranty", xlab = "Bad Buy?", main = "Relationship Between Warranty and Being a Bad Buy", data=cars)
##### None seem to be associated with the car being a lemon. Maybe odometer reading.

# 10)	 How many vehicles (using filter or sum):
# a.	Were red and have fewer than 30,000 miles?
sum (cars$Color == "RED", cars$VehOdo < 30000)
##### 6,519 cars
# b.	Are made by GMC and were purchased in Texas? 
sum (cars$Make == "GMC", cars$VNST == "Texas")
##### 648 cars
# c.	Are blue or red?
sum (cars$Color == "RED", cars$Color == "BLUE")
##### 16,587 cars
# d.	Are made by Chrysler or Nissan and are white or silver? 
sum ((cars$Make == "CHRYSLER" | cars$Make == "NISSAN") & (cars$Color == "WHITE" | cars$Color == "SILVER"))
##### 4,333 cars
# e.	Are automatic, blue, Pontiac cars with under 40,000 miles? 
sum (cars$Transmission == "AUTO" & cars$Color == "BLUE" & cars$Make == "PONTIAC" & cars$VehOdo < 40000)
##### 1 car