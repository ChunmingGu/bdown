####################
# 140.886: Intro to R
# Final Project
##################

# Remove varibles from workspace and install packages
rm(list=ls())

library(readr)
library(dplyr)
library(ggplot2)
library(tidyr)
library(reshape2)


######## READ DATA
# Read in data and rename TZ
TZ <- read_csv("C:/Users/Tricia/Dropbox/NEP TA Files/R course/Homework submission/Final Project/STATcompiler TZ data.csv")
View(TZ)

######## DATA MANIPULATION
# Remove unwanted columns and rows and rename sub_TZ
sub_TZ <- TZ[,c(3,5,6,7,8,9)]
sub_TZ <- sub_TZ[-c(1561:1632),]

# Rename columns
colnames(sub_TZ) <- c("year", "indicator", "time", "category", "tot_urb_rur", "value")

# Subset sub_TZ to focus on data since 1999 and only ANC4 and breastfeeding indicators. Removing missing values.
sub_TZ <- filter(sub_TZ, year>=1999)
sub_TZ <- filter(sub_TZ, indicator == 'Antenatal visits for pregnancy: 4+ visits' | indicator == 'Mean duration of any breastfeeding' | indicator == 'Mean duration of exclusive breastfeeding')
sub_TZ <- filter(sub_TZ, category == 'Total' | category == 'Residence')

have_sub_TZ = sub_TZ %>% filter(!is.na(value))

# Change names of specific indicators
have_sub_TZ$indicator[have_sub_TZ$indicator=="Antenatal visits for pregnancy: 4+ visits"] <- "ANC4"
have_sub_TZ$indicator[have_sub_TZ$indicator=="Mean duration of any breastfeeding"] <- "Any breastfeeding"
have_sub_TZ$indicator[have_sub_TZ$indicator=="Mean duration of exclusive breastfeeding"] <- "Exclusive breastfeeding"

# Subsets of ANC4+
## ANC4 mean (total)
sub_ANC = filter (have_sub_TZ, indicator == "ANC4", time == "Five years preceding the survey", tot_urb_rur == "Total")
## ANC4 mean (rural, urban)
sub_ANC_rur_urb = filter (have_sub_TZ, indicator == "ANC4", time == "Five years preceding the survey", tot_urb_rur == "Rural" | tot_urb_rur == "Urban")

## Duration of any breastfeeding mean
any_breastfeeding = filter (have_sub_TZ, indicator == "Any breastfeeding")

## Duration of exclusive breastfeeding mean
excl_breastfeeding = filter (have_sub_TZ, indicator == "Exclusive breastfeeding")

######## PLOTS
# ANC4 total by year
ggplot(data=sub_ANC, aes(x=year, y=value, group=1)) + ylim(0,100) + geom_line() + geom_point() + xlab("Year") + ylab("Percent of women attending 4+ ANC visits")+ggtitle("ANC4+ Coverage in Tanzania DHS 1999-2015")

# Mean duration (months) of any breastfeeding by year
ggplot(data=any_breastfeeding, aes(x=year, y=value, group=1)) + ylim(0,25) + geom_line() + geom_point() + xlab("Year") + ylab("Months")+ggtitle("Duration (months) of any breastfeeding in Tanzania DHS 1999-2015")

# Mean duration (months) of exclusive breastfeeding by year
ggplot(data=excl_breastfeeding, aes(x=year, y=value, group=1)) + ylim(0,5) + geom_line() + geom_point() + xlab("Year") + ylab("Months")+ggtitle("Duration (months) of exclusive breastfeeding in Tanzania DHS 1999-2015")

# Scatterplot ANC4+ vs. Duration of any breastfeeding
qplot(sub_ANC$value, any_breastfeeding$value) + xlab("ANC4+ coverage") + ylab("Any breastfeeding duration (months)") + ggtitle("ANC4+ coverage vs. Any breastfeeding duration (months) in Tanzania DHS 1999-2015")

# Scatterplot ANC4+ vs. Duration of exclusive breastfeeding
qplot(sub_ANC$value, excl_breastfeeding$value) + xlab("ANC4+ coverage") + ylab("Exclusive breastfeeding duration (months)") + ggtitle("ANC4+ coverage vs. Exclusive breastfeeding duration (months) in Tanzania DHS 1999-2015")

# ANC4 dot plot urban vs. rural
head(sub_ANC_rur_urb)
ggplot(sub_ANC_rur_urb, aes(x =value, y = year)) +
  geom_line(size=1, aes(group=year))+
  geom_point(size=10, aes(color = tot_urb_rur)) + xlim(0, 100) + xlab("ANC4+ coverage") + ylab("Year")+ggtitle("ANC4+ coverage by urban/rural in Tanzania DHS 1999-2015") + guides(colour = guide_legend(title = "Residence"))

######## BASIC STATISTICAL TESTS

# Correlation between ANC4+ and duration of any breastfeeding
cor.test(sub_ANC$value, any_breastfeeding$value)

# Correlation between ANC4+ and duration of exclusive breastfeeding
cor.test(sub_ANC$value, excl_breastfeeding$value)

# Relationship between ANC4+ and year (least-squares regression)
p <- ggplot(sub_ANC_rur_urb, aes(x = year, y = value)) +
     geom_point(size=3, aes(color = tot_urb_rur)) + 
     ylim(0,100) +
     stat_smooth(method="lm", se=TRUE) + 
     xlab("Year") + ylab("ANC4+ coverage") + 
     ggtitle("Relationship between ANC4+ coverage and year in Tanzania DHS 1999-2015") + 
     guides(colour = guide_legend(title = "Residence"))
p

p.output <- summary(lm(value ~ year, data=sub_ANC_rur_urb))
p.output
